HostGen is a Multipurpose Hosting Provider Responsive HTML5 Template. It's based on the latest stable Bootstrap 4.1.x. Also included WHMCS Template based on WHMCS v7.6. Anyone can easily update/edit this template to follow our Well Sorted Documentation.

Mainly, our template is an HTML template and we just provided support by customizing WHMCS header and footer and color based on our template for FREE of cost with our HTML template.


==========================================================================================================
WHMCS Template included in "whmcs-template" (folder) with installation instruction "readme.txt"
==========================================================================================================

==========================================================================
Well Sorted Documentation included in "documentation" (folder).
==========================================================================

==========================================================================
Changelog included in "documentation/changelog" (folder).
==========================================================================


SOURCE AND CREADITS:
====================

Photos:

    All 'images' used on the demo site is for demonstration purposes only and are not included in the main download file.

Fonts:

    Google Fonts (Muli and PT Sans)

Frameworks / Libraries:

    jQuery
    Twitter Bootstrap

Plugins:

    Isotope
    Light Box
    Parsley
    Retinajs
    Swiper
    Waypoints
    PHP Mailer